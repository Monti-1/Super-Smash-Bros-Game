To allow for this program to work a few things need to happen first.
1. Unzip the file
2. Ignore rename_images.py it is used to quickly rename files and should be ignored
3. ALWAYS run the program from the folder containing the python files.